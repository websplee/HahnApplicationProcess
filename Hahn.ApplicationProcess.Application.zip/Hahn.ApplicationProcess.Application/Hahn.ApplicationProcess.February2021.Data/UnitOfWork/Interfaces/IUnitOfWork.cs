﻿using Hahn.ApplicationProcess.February2021.Data.Repositories.Interfaces;
using Hahn.ApplicationProcess.February2021.Domain.Interfaces;
using System.Threading.Tasks;

namespace Hahn.ApplicationProcess.February2021.Data.UnitOfWork.Interfaces
{
    public interface IUnitOfWork<T> where T : class, IEntityBase, new()
    {
        IRepository<T> Entity { get; }

        Task SaveChangesAsync();
    }
}
