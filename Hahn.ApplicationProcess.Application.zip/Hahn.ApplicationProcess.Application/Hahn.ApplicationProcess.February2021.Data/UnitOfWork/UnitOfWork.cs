﻿using Hahn.ApplicationProcess.February2021.Data.Repositories;
using Hahn.ApplicationProcess.February2021.Data.Repositories.Interfaces;
using Hahn.ApplicationProcess.February2021.Data.UnitOfWork.Interfaces;
using Hahn.ApplicationProcess.February2021.Domain.Interfaces;
using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;

namespace Hahn.ApplicationProcess.February2021.Data.UnitOfWork
{
    public class UnitOfWork<T> : IUnitOfWork<T> where T : class, IEntityBase, new()
    {
        readonly HahnDbContext _context;
        readonly IHttpContextAccessor _httpAccessor;

        IRepository<T> _entity;

        public UnitOfWork(HahnDbContext context, IHttpContextAccessor httpAccessor)
        {
            _context = context;
            _httpAccessor = httpAccessor;
        }

        public IRepository<T> Entity
        {
            get
            {
                if (_entity == null)
                {
                    _entity = new Repository<T>(_context);
                }

                return _entity;
            }
        }

        public Task SaveChangesAsync()
        {
            return _context.SaveChangesAsync();
        }
    }
}
