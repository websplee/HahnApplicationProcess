using Hahn.ApplicationProcess.February2021.Data;
using Hahn.ApplicationProcess.February2021.Web.InitialData;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Serilog;

namespace Hahn.ApplicationProcess.February2021.Web
{
    public class Program
    {
        public static void Main(string[] args)
        {
            // Hook the web host
            var host = CreateHostBuilder(args).Build();

            //2. Find the service layer within our scope.
            using (var scope = host.Services.CreateScope())
            {
                //3. Get the instance of HahnDbContext in our services layer
                var services = scope.ServiceProvider;
                var context = services.GetRequiredService<HahnDbContext>();

                //4. Call the Seeding class to create sample data
                SeedData.Initialize(services);
            }

            //Continue to run the application
            host.Run();
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseStartup<Startup>();
                })
            .UseSerilog((hostingContext, loggerConfig) =>
                  loggerConfig.ReadFrom.Configuration(hostingContext.Configuration)
            );
    }
}