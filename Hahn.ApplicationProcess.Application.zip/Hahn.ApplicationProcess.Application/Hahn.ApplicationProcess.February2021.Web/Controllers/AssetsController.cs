﻿using AutoMapper;
using FluentValidation.AspNetCore;
using Hahn.ApplicationProcess.February2021.Data.UnitOfWork.Interfaces;
using Hahn.ApplicationProcess.February2021.Domain.Models;
using Hahn.ApplicationProcess.February2021.Domain.Validators;
using Hahn.ApplicationProcess.February2021.Web.CustomExceptions.Exceptions;
using Hahn.ApplicationProcess.February2021.Web.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Hahn.ApplicationProcess.February2021.Web.Controllers
{
    [Route("api/v1/[controller]")]
    [ApiController]
    public class AssetsController : ControllerBase
    {
        private readonly ILogger _logger;
        private readonly IMapper _mapper;
        private IUnitOfWork<Asset> _unitOfWork;

        public AssetsController(ILogger<AssetsController> logger, IMapper mapper, IUnitOfWork<Asset> unitOfWork)
        {
            _logger = logger;
            _mapper = mapper;
            _unitOfWork = unitOfWork;
        }

        /// <summary>
        /// Gets a single asset by Id
        /// </summary>
        /// <returns></returns>
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(AssetViewModel))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [HttpGet("{id}")]
        public ActionResult<Asset> Get(int id)
        {
            var asset = _unitOfWork.Entity.GetSingle(a => a.Id == id).FirstOrDefault();
            if (asset == null)
                throw new BadRequestException($"Record Id {id} not found");
            return Ok(asset);
        }

        /// <summary>
        /// Gets a listing of all assets on database
        /// </summary>
        /// <returns></returns>
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<AssetViewModel>))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [HttpGet]
        public ActionResult<IEnumerable<Asset>> Get()
        {
            var assets = _unitOfWork.Entity.GetAll();

            return Ok(assets);

        }

        /// <summary>
        /// Takes in valid asset values and commits that to the in memory database. If the values are not valid, user is prompted accordingly.
        /// </summary>
        /// <param name="newAssetViewModel"></param>
        /// <returns></returns>
        [ProducesResponseType(StatusCodes.Status201Created, Type = typeof(AssetViewModel))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [HttpPost]
        public async Task<IActionResult> Post([FromBody] AssetViewModel newAssetViewModel)
        {
            
            // Validate model state
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var newAsset = _mapper.Map<Asset>(newAssetViewModel);

            var validator = new AssetValidator();
            var results = validator.Validate(newAsset);

            results.AddToModelState(ModelState, null);

            // Validate model state
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _unitOfWork.Entity.Add(newAsset);
            await _unitOfWork.SaveChangesAsync();

            DateTime parsedDate;

            DateTime.TryParseExact(newAsset.PurchaseDate.ToShortDateString(), "yyyy-MM-dd", null, DateTimeStyles.None, out parsedDate);

            newAsset.PurchaseDate = parsedDate;

            return CreatedAtAction("Post", new { id = newAsset.Id }, newAsset);

        }

        /// <summary>
        /// Edits a record given its Id and the edited record.
        /// Checks if the ids are the same, if not, it throws an exception
        /// </summary>
        /// <param name="id"></param>
        /// <param name="editedAssetViewModel"></param>
        /// <returns></returns>
        [ProducesResponseType(StatusCodes.Status201Created, Type = typeof(AssetViewModel))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [HttpPut("{id}")]
        public async Task<IActionResult> Put(int id, [FromBody] AssetViewModel editedAssetViewModel)
        {
            // Validate model state
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            // map the edited asset view model to the model
            var editedAsset = _mapper.Map<Asset>(editedAssetViewModel);

            var validator = new AssetValidator();
            var results = validator.Validate(editedAsset);

            results.AddToModelState(ModelState, null);

            // Validate model state
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            // Check if the Id for the item being edited and the supplied Ids are the same
            if (editedAssetViewModel.Id != id)
                throw new BadRequestException($"Id passed {id} is not equal to Id of asset {editedAssetViewModel.Id}");


            var count = _unitOfWork.Entity.GetSingle(x => x.Id == id).Count();

            if (count < 1)
                throw new NotFoundException($"Asset Id = {id} not found");
            
            
            // save 
            _unitOfWork.Entity.Update(editedAsset);
            await _unitOfWork.SaveChangesAsync();

            return CreatedAtAction("Post", new { id = editedAsset.Id }, editedAsset);

        }

        /// <summary>
        /// Deletes record by Id. If the record is not found it throws an exception.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            // Search for the asset by ID, if not found throw error. Else delete
            var originalAsset = _unitOfWork.Entity.GetSingle(x => x.Id == id).First();

            if (originalAsset == null)
                throw new NotFoundException($"Asset Id = {id} not found");

            // save 
            _unitOfWork.Entity.DeleteWhere(a => a.Id == id);
            await _unitOfWork.SaveChangesAsync();

            return NoContent();

        }
    }
}
