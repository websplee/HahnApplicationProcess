﻿using Hahn.ApplicationProcess.February2021.Data;
using Hahn.ApplicationProcess.February2021.Domain.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Linq;

namespace Hahn.ApplicationProcess.February2021.Web.InitialData
{
    public class SeedData
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new HahnDbContext(
                serviceProvider.GetRequiredService<DbContextOptions<HahnDbContext>>()))
            {
                // Look for any board games.
                if (context.Assets.Any())
                {
                    return;   // Data was already seeded
                }

                context.Assets.AddRange(
                    new Asset
                    {
                        Id = 1,
                        AssetName = "Laptop",
                        Department = Domain.Enums.Department.HQ,
                        CountryOfDepartment = "Zambia",
                        EmailAddressOfDepartment = "a@hahn.com",
                        PurchaseDate = DateTime.UtcNow.AddDays(-200),
                        Broken = true
                    },new Asset
                    {
                        Id = 2,
                        AssetName = "Merc",
                        Department = Domain.Enums.Department.MaintenanceStation,
                        CountryOfDepartment = "Germany",
                        EmailAddressOfDepartment = "b@hahn.com",
                        PurchaseDate = DateTime.UtcNow.AddDays(-250),
                        Broken = false
                    },new Asset
                    {
                        Id = 3,
                        AssetName = "Workstation",
                        Department = Domain.Enums.Department.Store1,
                        CountryOfDepartment = "Malawi",
                        EmailAddressOfDepartment = "c@hahn.com",
                        PurchaseDate = DateTime.UtcNow.AddDays(-100),
                        Broken = true
                    },new Asset
                    {
                        Id = 4,
                        AssetName = "Fridge",
                        Department = Domain.Enums.Department.Store2,
                        CountryOfDepartment = "Russia",
                        EmailAddressOfDepartment = "d@hahn.com",
                        PurchaseDate = DateTime.UtcNow.AddDays(-89),
                        Broken = false
                    },new Asset
                    {
                        Id = 5,
                        AssetName = "Eifel Towers",
                        Department = Domain.Enums.Department.Store3,
                        CountryOfDepartment = "France",
                        EmailAddressOfDepartment = "e@hahn.com",
                        PurchaseDate = DateTime.UtcNow.AddDays(-287),
                        Broken = true
                    }) ;

                context.SaveChanges();
            }
        }
    }
}
