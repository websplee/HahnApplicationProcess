﻿using Hahn.ApplicationProcess.February2021.Domain.Interfaces;
using System;

namespace Hahn.ApplicationProcess.February2021.Domain.Models
{
    public class Asset : IEntityBase
    {
        /// <summary>
        /// Primary key for asset - auto increment
        /// </summary>
        /// <example>25</example>
        public long Id { get; set; }
        /// <summary>
        /// The name of the asset
        /// </summary>
        /// <example>Laptop</example>
        public string AssetName { get; set; }
        /// <summary>
        /// Department value picked from enum
        /// </summary>
        /// <example>2</example>
        public Enums.Department Department { get; set; }
        /// <summary>
        /// Country valided against provided API endpoint
        /// </summary>
        /// <example>Zambia</example>
        public string CountryOfDepartment { get; set; }
        /// <summary>
        /// Valid email address for the department
        /// </summary>
        /// <example>J@hahn.com</example>
        public string EmailAddressOfDepartment { get; set; }
        /// <summary>
        /// UTC date when purchase is made
        /// </summary>
        /// <example>2021-06-04</example>
        public DateTime PurchaseDate { get; set; }
        /// <summary>
        /// Is asset broken 1 = true, default false = 0
        /// </summary>
        /// <example>1</example>
        public bool Broken { get; set; }
    }
}
