﻿using FluentValidation;
using Hahn.ApplicationProcess.February2021.Domain.Models;
using Newtonsoft.Json.Linq;
using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace Hahn.ApplicationProcess.February2021.Domain.Validators
{
    public class AssetValidator : AbstractValidator<Asset>
    {
        public AssetValidator()
        {
            // This rule ensures that the assetname is not empty or less than 5 characters
            RuleFor(asset => asset.AssetName)
                .NotEmpty().WithMessage("{PropertyName} should not be empty")
                .MinimumLength(5);
            // This rule ensures that the department value is part of the enum values in department enumerator
            RuleFor(asset => asset.Department)
                .IsInEnum();
            // Check if the country entered is valid
            RuleFor(asset => asset.CountryOfDepartment)
                .NotEmpty().WithMessage("{PropertyName} should not be empty")
                .Must(c => ValidateCountryFullname(c).GetAwaiter().GetResult())
                .WithMessage("{PropertyName} does not exist!!");
            // Purchase date must not be older than one year
            RuleFor(asset => asset.PurchaseDate)                
                .Must(date => DateTime.UtcNow.Subtract(date).TotalDays < 366) // 365 gives one year
                .WithMessage("{PropertyName} must not be older than one year (or make sure it is a valid UTC date)");
            // Valid email address
            RuleFor(asset => asset.EmailAddressOfDepartment)
                .NotEmpty().WithMessage("{PropertyName} should not be empty")
                .EmailAddress();
            // 
        }        

        /// <summary>
        /// Calls the https://restcountries.eu/rest/v2/name/zabia?fullText=true endpoint to verify the country fullname
        /// </summary>
        /// <param name="countryFullname"></param>
        /// <returns></returns>
        private async Task<bool> ValidateCountryFullname(string countryFullname)
        {
            using (var client = new HttpClient())
            {
                HttpResponseMessage response = null;

                client.BaseAddress = new Uri("https://restcountries.eu/rest/v2/name/");
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                try // make the call to the endpoint
                {
                    response = await client.GetAsync($"{countryFullname}?fullText=true");                    
                    // response.EnsureSuccessStatusCode();                    
                }
                catch (Exception error)
                {
                    throw new Exception(error.Message);
                }

                if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
                    return false;
                else
                    return true;
            }
        }
    }
}
