export class AssetModel {
  id: number;
  assetName: string;
  department: Department;
  countryOfDepartment: string;
  emailAddressOfDepartment: string;
  purchaseDate: Date;
  broken: boolean = false;
}

export enum Department {
  HQ,
  Store1,
  Store2,
  Store3,
  MaintenanceStation
}
