import { HttpClient, json } from 'aurelia-fetch-client';
import { inject } from 'aurelia-framework';

let httpClient = new HttpClient();

@inject({ providedIn: 'root' })
export class RepositoryService {
  private data: any;
  private headers: Headers = new Headers();
  private apiURL: string = "https://localhost:5001/api/v1" // Tried reading env variables to no avail
  // private apiURL: string = environment.configure. + '/' + environment.apiVersion;


  public getData(route: string) {
    
    this.generateHeaders();
    return httpClient.fetch(this.createCompleteRoute(route, this.apiURL), { headers: this.headers });
      
  }
  

  public create(route: string, body) {
    this.generateHeaders();
    return httpClient.post(this.createCompleteRoute(route, this.apiURL), JSON.stringify(body), { headers: this.headers });
  }

  public update(route: string, body) {
    this.generateHeaders();
    return httpClient.put(this.createCompleteRoute(route, this.apiURL), JSON.stringify(body), { headers: this.headers });
  }

  public delete(route: string) {
    this.generateHeaders();
    return httpClient.delete(this.createCompleteRoute(route, this.apiURL), { headers: this.headers });
  }

  private createCompleteRoute(route: string, apiAddress: string) {
    return `${apiAddress}/${route}`;
  }

  private generateHeaders() {
    

    this.headers = new Headers({
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
    });
  } 
}
