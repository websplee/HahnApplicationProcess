import {PLATFORM} from 'aurelia-pal';
import {Router, RouterConfiguration} from 'aurelia-router';

export class App {
  public router: Router;

  public configureRouter(config: RouterConfiguration, router: Router): Promise<void> | PromiseLike<void> | void {
    config.title = 'Asset Manager';
    config.map([
      {
        route: ['', 'home'],
        name: 'home',
        moduleId: PLATFORM.moduleName('./assets/list/list'),
        nav: true,
        title: 'Assets List'
      },    
      {
        route: 'new',
        name: 'new',
        moduleId: PLATFORM.moduleName('./assets/new/new'),
        nav: true,
        title: 'New Asset'
      },         
    ]);
    this.router = router;
  }
}
