export class Delete {
  message: string;

  constructor() {
    this.message = 'Hello world';
  }
}
