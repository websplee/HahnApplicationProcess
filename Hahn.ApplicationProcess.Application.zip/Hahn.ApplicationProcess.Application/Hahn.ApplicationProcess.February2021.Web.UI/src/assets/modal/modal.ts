import { autoinject } from 'aurelia-framework';
import { ValidationController } from 'aurelia-validation';
import { DialogController } from 'aurelia-dialog';

@autoinject

export class Prompt {
  private message: string;
  // private controller: ValidationController;
  private answer: any;

  constructor(private controller: DialogController) {
    controller.settings.centerHorizontalOnly = false;
  }
  activate(message) {
    this.message = message;
  }

  ok(): void {
    this.controller.ok();
  }

  cancel(): void {
    this.controller.ok();
  }
}
