import { autoinject } from 'aurelia-dependency-injection';
import { DialogService } from 'aurelia-dialog';
import {
    validateTrigger, ValidationController,
    ValidationControllerFactory,
    ValidationRules, Validator
} from 'aurelia-validation';
import { BootstrapFormRenderer } from '../../bootstrap-form-renderer';
import { AssetModel } from '../../models/assetModel';
import { RepositoryService } from '../../services/repository.service';
import { Prompt } from '../modal/modal';

@autoinject
export class newForm {
  asset: AssetModel = new AssetModel();
  private canSave: Boolean = true;
  private canReset: Boolean = true;
  private controller: ValidationController;
  private dialogService: DialogService;
  private apiRoute: string = '';

  constructor(private validator: Validator, controllerFactory: ValidationControllerFactory, dialogService: DialogService, private repo: RepositoryService) {
    this.dialogService = dialogService;
    this.controller = controllerFactory.createForCurrentScope(validator);
    this.controller.validateTrigger = validateTrigger.changeOrBlur;
    this.controller.addRenderer(new BootstrapFormRenderer());
    this.controller.subscribe(event => this.validateWhole());
  }

  public submit() {
    if (!this.canSave) {
      return;
    }
    this.controller.validate();
    this.apiRoute = 'assets';
    this.asset.id = 0; 
    console.log(this.asset);
    return this.repo.create(this.apiRoute, this.asset)
      .then(response => response.json())
      .then(data => this.asset = data)
      .then(savedComment => alert('Record successfully saved'))
      .catch(error => {
        alert('Error saving comment!');
      });


  }

  public reset() {
    this.dialogService.open({ viewModel: Prompt, model: 'Are you sure you want to reset the form?' }).whenClosed(response => {
      console.log(response.output);

      if (!response.wasCancelled) {
        this.asset = null;
      }
    });
  }

  public activate(params) {   
    this.setupValidation();
  }

  public setupValidation() {
    ValidationRules.customRule(
      'dateA',
      (value, obj) => value === null || value === undefined || value instanceof Date,
      `\${$displayName} must be a Date.`
    );

    ValidationRules
      .ensure('assetName').required().minLength(5)
      .ensure('department').required().range(0,4)
      .ensure('countryOfDepartment').required()
      .ensure('purchaseDate').required()
      .ensure('emailAddressOfDepartment').required().email()
      .ensure('purchaseDate').required()
      // .ensure('purchaseDate').required().satisfiesRule('dateA') // Date validation is giving error
      .ensure('broken').required()
      .on(this.asset);
  }

  private validateWhole() {
    this.validator.validateObject(this.asset)
      .then(results => this.canSave = results.every(result => result.valid));
  }
}
