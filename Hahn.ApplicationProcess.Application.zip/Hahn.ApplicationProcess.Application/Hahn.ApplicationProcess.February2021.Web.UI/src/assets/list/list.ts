import { RepositoryService } from "../../services/repository.service";
import { HttpClient, json } from 'aurelia-fetch-client';
import { inject } from 'aurelia-framework';
import { AssetModel } from "../../models/assetModel";

@inject(RepositoryService)
export class List {
  assets: AssetModel[] = new Array<AssetModel>();
  countries: string[] = [];

  pageSize = 10;

  apiRoute: string = '';

  filters = [
    { value: '', keys: ['assetName', 'department', 'countryOfDepartment', 'emailAdressOfDepartment'] },
    { value: '', keys: ['countryOfDepartment'] },
  ];

  constructor(private repo: RepositoryService) { }

  bind() {
    this.apiRoute = 'assets';
    return this.repo.getData(this.apiRoute)
      .then(response => response.json())
      .then(data => this.assets = data)
      .then(() => this.populateCountries());
  }

  selectLast() {
    let last = this.assets[this.assets.length - 1];
  }

  rowSelected($event) {
    console.log($event.detail.row);
  }

  populateCountries() {
    this.countries.push('');
    for (let next of this.assets) {
      let nextCountry = next.countryOfDepartment;

      if (this.countries.indexOf(nextCountry) === -1) {
        this.countries.push(nextCountry);
      }
    }
  }
}
