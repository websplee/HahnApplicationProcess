export class Edit {
  message: string;

  constructor() {
    this.message = 'Hello world';
  }
}
